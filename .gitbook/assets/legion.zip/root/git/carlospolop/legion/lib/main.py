#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys, os, re

from warriors.http_warrior import Http_warrior
from warriors.generic_warrior import Generic_warrior
from warriors.dns_warrior import Dns_warrior
from warriors.smb_warrior import Smb_warrior
from warriors.ldap_warrior import Ldap_warrior
from warriors.snmp_warrior import Snmp_warrior
from warriors.rpc_warrior import Rpc_warrior
from warriors.ike_warrior import Ike_warrior
from warriors.mssql_warrior import Mssql_warrior


valid_protos = ["generic", "http", "https", "dns", "smb", "ldap", "snmp", "rpc", "ike", "mssql", "/"]


def main_run(parser, proto, host, workdir, port, ebrute, username, ulist, plist, protohelp, notuse, engine, password, ipv6, domain,
             interactive, verbose):
    if not proto in valid_protos:
        if not interactive:
            parser.print_help(sys.stderr)
            sys.exit(1)
        else:
            print("Protocol "+proto+" is not valid")
            return -1

    if not protohelp and (not os.path.isdir(workdir) or not os.access(workdir, os.W_OK)):
        if not interactive:
            parser.print_help(sys.stderr)
            print("No directory or directory not writable: " + workdir)
            sys.exit(2)
        else:
            print("No directory or directory not writable: " + workdir)
            return -1

    if not protohelp and not host:
        if not interactive:
            parser.print_help(sys.stderr)
            print("A host is needed")
            sys.exit(3)
        else:
            print("Please, set a host")
            return -1

    if not re.match("^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$", host) and not re.match(
            "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$",
            host):
        if not interactive:
            parser.print_help(sys.stderr)
            print("The provided host is not and IP nor a valid Domain")
            sys.exit(4)
        else:
            print("The provided host is not and IP nor a valid Domain")
            return -1


    if proto == "http":
        warrior = Http_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, engine, domain,
                               interactive, verbose)

    elif proto == "https":
        warrior = Http_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, engine, domain,
                               interactive, verbose)

    elif proto == "generic":
        warrior = Generic_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive,
                                  verbose)

    elif proto == "dns":
        warrior = Dns_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, ipv6, domain,
                              interactive, verbose)

    elif proto == "smb":
        warrior = Smb_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp,
                              interactive, verbose)

    elif proto == "ldap":
        warrior = Ldap_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp,
                               interactive, verbose)

    elif proto == "snmp":
        warrior = Snmp_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp,
                               interactive, verbose)

    elif proto == "rpc":
        warrior = Rpc_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp,
                              interactive, verbose)

    elif proto == "ike":
        warrior = Ike_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp,
                              interactive, verbose)

    elif proto == "mssql":
        warrior = Mssql_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp,
                              interactive, verbose)

    if not interactive:
        warrior.run()
    else:
        return warrior
