#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os, sys, signal

from threading import Thread
from termcolor import colored
from cmd import Cmd
from time import sleep

from lib.main import main_run
from warriors.general import General


class LegionPrompt(Cmd):
    intro = "I wanted to destroy everything beautiful I'd never have.\n"
    prompt = '(legion) '

    def __init__(self, parser, proto, host, workdir, port, ebrute, username, ulist, plist, protohelp, notuse, engine, password, ipv6, \
        domain, verbose):
        Cmd.__init__(self)
        self.all_values = {"proto": proto, "host": host, "workdir": workdir, "port": port, "ebrute": ebrute, "username": username,
            "ulist": ulist, "plist": plist, "protohelp": False, "password": password, "plist": plist, "notuse": notuse,
            "engine": engine, "ipv6": ipv6, "domain": domain, "verbose": verbose}
        self.interactive = True
        self.parser = parser
        self.ws = []
        self.general = ""

    def emptyline(self):
        pass

    def do_exit(self, inp):
        '''exit the application'''
        print("Bye!")
        self.stop_procs()
        os.kill(os.getpid(), signal.SIGTERM)

    def do_quit(self, inp):
        '''exit the application'''
        print("Bye!")
        self.stop_procs()
        os.kill(os.getpid(), signal.SIGTERM)

    def do_stopall(self, inp):
        self.stop_procs()


    def do_set(self, args):
        '''Set variable value: set proto http'''
        if len(args.split(" ")) < 2:
            print(colored("[-] Error. set <variable> <value>", "red"))
        else:
            variable = args.split(" ")[0].lower()
            value = args.split(" ")[1]
            if variable.lower() in self.all_values:
                value = value if not value.lower() in ["true", "false"] else (True if value.lower() == "true" else False)
                self.all_values[variable] = value
                print(variable + ": " + str(value))
            else:
                print(variable + " is not valid")

    def do_get(self, args):
        '''Get variable value: get proto'''
        variable = args.split(" ")[0].lower()
        if variable.lower() in self.all_values:
            print(variable + ": " + str(self.all_values[variable]))
        else:
            print(variable + " is not valid")

    def do_getopts(self, _):
        '''Get all Parameters and their value'''
        for v in self.all_values:
            print(colored(str(v)+": ", 'cyan')+str(self.all_values[v]))

    def do_getprocs(self, _):
        '''Get information about running and run processes'''
        self.print_procs(self.ws)
        if self.general != "":
            print(colored("Warriors sent by the General:", "blue"))
            self.print_procs(self.general.get_warriors())

    def do_getout(self, filename):
        '''Get the output of a executed tool: getout smbclient'''
        name = filename + ".out"
        for root, dirs, files in os.walk(self.all_values["workdir"]+"/"+self.all_values["host"]):
            if name in files:
                with open(os.path.join(root, name), 'r') as f:
                    print(f.read())
                    break

    def do_geterr(self, filename):
        '''Get the error of a executed tool: geterr smbclient'''
        name = filename + ".err"
        for root, dirs, files in os.walk(self.all_values["workdir"]):
            if name in files:
                with open(os.path.join(root, name), 'r') as f:
                    print(f.read())
                    break

    def do_run(self, _):
        '''Execute the confiured protocol attack'''
        warrior = main_run( self.parser, self.all_values["proto"], self.all_values["host"], self.all_values["workdir"],
        self.all_values["port"], self.all_values["ebrute"], self.all_values["username"], self.all_values["ulist"],
        self.all_values["plist"], self.all_values["protohelp"], self.all_values["notuse"], self.all_values["engine"],
        self.all_values["password"], self.all_values["ipv6"], self.all_values["domain"], self.interactive, self.all_values["verbose"] )
        self.ws.append(warrior)

        if warrior != -1: #If -1, then something went wrong creating the warrior
            thread = Thread(target=warrior.run)
            thread.start()
        else:
            print(colored("[-] Something went wrong, nothing is gonig to be executed", "red"))

    def do_startGeneral(self, _):
        '''Star a General that will help. Automatize the scan and launch of scripts depending on the discovered services. Only one at the same time is allowed.'''
        if self.general == "":
            print(colored("Starting General","blue"))
            self.general = General(self.parser, self.all_values["host"], "0", self.all_values["workdir"], "/", self.all_values["ebrute"],
                        self.all_values["username"], self.all_values["ulist"], self.all_values["password"], self.all_values["plist"],
                        self.all_values["notuse"], self.all_values["protohelp"], self.interactive, self.all_values["verbose"])
            thread = Thread(target=self.general.run)
            thread.start()
        else:
            print(colored("general is already running... You can stop it with stopGeneral",'red'))

    def do_stopGeneral(self, _):
        '''Stop the general'''
        print("Stopping General...")
        self.general.stop_general()
        self.general = ""

    def print_procs(self, ws):
        for w in ws:
            procs, ch = w.get_procs_info()
            print(colored(w.get_proto(), 'blue', attrs=['reverse']))
            for p in procs:
                if p["proc"].is_alive():
                    print(colored(p["name"] + ": ", 'yellow', attrs=['blink']) + p["cmd"])
                else:
                    print(colored(p["name"] + ": ", 'green') + p["cmd"])
            if ch:
                print(colored("Command require sequencial object, waiting for execute next commnad...", 'red'))

    def stop_procs(self):
        self.proc_stop_procs(self.ws)
        if self.general != "":
            self.proc_stop_procs(self.general.get_warriors())

    def proc_stop_procs(self, ws):
        rep = True
        while rep:
            rep = False
            for w in ws:
                procs, ch = w.get_procs_info()
                for p in procs:
                    if p["proc"].is_alive():
                        rep = True
                        print(colored("Terminating: ", 'red') + p["name"])
                        p["proc"].terminate()
                        sleep(0.2)