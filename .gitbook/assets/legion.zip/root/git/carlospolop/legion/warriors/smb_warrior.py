# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#You can test this module against sizzle.htb (10.10.10.103)

class Smb_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose):
        port = port if port != "0" else "445"
        Warrior.__init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)

        self.cmds = [
            {"name": "enum4linux", "cmd": 'enum4linux -a -u "'+self.username+'" -p "'+self.password+'" '+self.host, "shell": True,
             "chain": False},
            {"name": "nmap_safe_smb", "cmd": 'nmap -sV --script "(safe and smb*) or smb-enum-*" -p '+self.port+' ' + self.host, "shell": True,
             "chain": False},
            {"name": "smbmap", "cmd": 'smbmap -u "'+self.username+'" -p "'+self.password+'" -H '+self.host+" -P "+self.port, "shell": True,
             "chain": False},
            {"name": "smbclient", "cmd": 'smbclient --no-pass -L //' + self.host, "shell": False, "chain": False},
            {"name": "nbtscan", "cmd": 'nbtscan ' + self.host, "shell": False, "chain": False},
            #{"name": "msf_smb_version", "cmd": 'msfconsole - x "use scanner/smb/smb_version; set rhosts '+self.host+'; run; exit;"', "shell": True, "chain": False},
        ]

        if self.protohelp:
            self.print_help()
