# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#Revisado
#apt-get install snmp-mibs-downloader
# in /etc/snmp/snmp.conf comment the line "mibs :"

#You can test this module against condeal.htb (10.10.10.116)

class Snmp_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose):
        port = port if port != "0" else "161"
        Warrior.__init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)
        self.community = self.password if len(self.password)>0 else "public"
        self.wordlist = self.plist if self.plist != "" else self.wordlists_path+'/snmp_default_pass.txt'
        self.community = self.community if not self.protohelp else "<COMMUNITY>"

        self.cmds = [
            {"name": "snmpwalkv1", "cmd": 'snmpwalk -v 1 -c ' + self.community + ' ' + self.host, "shell": False, "chain": False},
            {"name": "snmpwalkv2c", "cmd": 'snmpwalk -v 2c -c ' + self.community + ' ' + self.host, "shell": False, "chain": False},

        ]

        if self.ip != "":
            self.cmds.append({"name": "snmp-check", "cmd": 'snmp-check -p '+ self.port + ' -c ' + self.community + ' ' + self.ip,
                              "shell": False, "chain": False})

        if self.ebrute or self.protohelp:
            self.cmds.append({"name": "hydra_snmp", "cmd": 'hydra -P ' + self.wordlist + ' -f ' + self.host + ' snmp -s '+self.port,
                              "shell": False, "chain": False})

        if self.protohelp:
            self.print_help()
