# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#apt-get install rpcbind
#You can check this module with irked.htb (10.10.10.117)

class Rpc_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose):
        port = port if port != "0" else "111"
        Warrior.__init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)

        self.cmds = [
            {"name": "rpcinfo", "cmd": 'rpcinfo ' + self.host, "shell": False, "chain": False},

        ]

        if self.protohelp:
            self.print_help()
