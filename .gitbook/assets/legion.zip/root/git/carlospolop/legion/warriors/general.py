# -*- coding: utf-8 -*-

import os

from time import sleep
from termcolor import colored
from threading import Thread

from warriors.warrior import Warrior
from lib.main import main_run

#The workdir of general is /home/username/.legion/host//

class General(Warrior):
    def __init__(self, parser, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose):
        self.parser = parser
        self.port = "0"
        Warrior.__init__(self, host, self.port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)
        self.engine, self.ipv6 = "", ""
        self.protohelp = False
        self.checked = []
        self.stop = False
        self.ws = []

    def run_proto(self, proto, port, brute):
        warrior = main_run(self.parser, proto, self.host, self.workdir+"/../../", port, brute, self.username, self.ulist, self.plist, self.protohelp,
                 self.notuse, self.engine, self.password, self.ipv6, self.domain, self.interactive, self.verbose)
        self.ws.append(warrior)
        thread = Thread(target=warrior.run)
        thread.start()

    def get_warriors(self):
        return self.ws

    def run(self):
        self.run_proto("generic", "1337", True)

        while not self.stop:
            for root, dirs, files in os.walk(self.workdir+"/../generic/"):
                for file in files:
                    with open(os.path.join(root, file), 'r') as f:
                        cont = f.readlines()

                    self.check_cont(cont, file)
            sleep(2)


    def check_cont(self, cont, file):
        if "nmap" in file:
            for line in cont:
                if line[0] in '1234567890': #If 1st number, then port
                    port = line.split("/")[0]
                    if "tcp" in line and "open" in line:
                        if ("443/tcp" in line or "https" in line or ("http" in line and "ssl" in line)) and not port+"/tcp-https" in self.checked:
                            print(line)
                            print(colored("Found "+str(port)+" opened for https, sending warriors... (gen)", "blue"))
                            self.run_proto("https", port, True)
                            self.checked.append(port+"/tcp-https")

                        elif ("80/tcp" in line or ("http" in line and not "ssl" in line and not "https" in line)) and not port+"/tcp-http" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for http, sending warriors... (gen)", "blue"))
                            self.run_proto("http", port, True)
                            self.checked.append(port+"/tcp-http")

                        elif ("389/tcp" in line or "ldap" in line) and not port+"/tcp-ldap" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for ldap, sending warriors... (gen)", "blue"))
                            self.run_proto("ldap", port, True)
                            self.checked.append(port+"/tcp-ldap")

                        elif ("111/tcp" in line or "rpcbind" in line) and not port+"/tcp-rpcbind" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for rpcbind, sending warriors... (gen)", "blue"))
                            self.run_proto("rpcbind", port, True)
                            self.checked.append(port+"/tcp-rpcbind")

                        elif ("445/tcp" in line or "microsoft-ds" in line) and not port+"/tcp-microsoft-ds" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for smb, sending warriors... (gen)", "blue"))
                            self.run_proto("smb", port, False)
                            self.checked.append(port+"/tcp-microsoft-ds")

                        elif ("1433/tcp" in line or "ms-sql-s" in line) and not port+"/mssql" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for mssql, sending warriors... (gen)", "blue"))
                            self.run_proto("mssql", port, False)
                            self.checked.append(port+"/mssql")

                    elif "udp" in line and "open" in line:
                        if ("53/udp" in line or "domain" in line or "dns" in line) and not port+"/udp-dns" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for dns, sending warriors... (gen)", "blue"))
                            self.run_proto("dns", port, True)
                            self.checked.append(port+"/udp-dns")

                        elif ("500/udp" in line or "isakmp" in line) and not port+"/udp-ike" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for ike, sending warriors... (gen)", "blue"))
                            self.run_proto("ike", port, True)
                            self.checked.append(port+"/udp-ike")

                        elif ("161/udp" in line or "snmp" in line) and not port+"/udp-snmp" in self.checked:
                            print(line)
                            print(colored("Found " + str(port) + " opened for snmp, sending warriors... (gen)", "blue"))
                            self.run_proto("snmp", port, True)
                            self.checked.append(port+"/udp-snmp")

        if "udp-proto-scanner" in file:
            for line in cont:
                if line.split(" ")[0] == "Received":
                    if "snmp-public" in line and not "161/udp-snmp" in self.checked:
                        print(line)
                        print(colored("Found 161 opened for snmp, sending warriors... (gen)", "blue"))
                        self.run_proto("snmp", "161", True)
                        self.checked.append("161/udp-snmp")

                    if "ike" in line and not "500/udp-ike" in self.checked:
                        print(line)
                        print(colored("Found 500 opened for ike, sending warriors... (gen)", "blue"))
                        self.run_proto("snmp", "500", True)
                        self.checked.append("500/udp-ike")


    def stop_general(self):
        self.stop = True
