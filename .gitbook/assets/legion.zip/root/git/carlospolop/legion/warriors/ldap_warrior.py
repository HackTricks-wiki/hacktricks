# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#You can test this module against sizzle.htb (10.10.10.103) and ypuffy (10.10.10.107)

class Ldap_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose):
        port = port if port != "0" else "389"
        Warrior.__init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)

        self.cmds = [
            {"name": "nmap_ldap", "cmd": 'nmap -sV --script "ldap* and not brute" -p ' + self.port + ' ' + self.host, "shell": False, "chain": False},
        ]

        #The script ldap-brute lock accounts very fast, is better to not use it
        #if self.ebrute or self.protohelp:
        #    self.cmds = [
        #        {"name": "nmap_ldap", "cmd": 'nmap -sV --script "ldap*" -p ' + self.port + ' ' + self.host, "shell": False,
        #         "chain": False},
        #    ]

        if self.protohelp:
            self.print_help()
