# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

# https://github.com/gwen001/vhost-brute

class Http_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, engine, domain, interactive, verbose):
        port = port if port != "0" else ("80" if proto == "http" else "443")
        Warrior.__init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)
        self.engine = engine if not self.protohelp else "<ENGINE>"
        self.engine = self.engine if self.engine else "php,asp,aspx"
        self.usernames = ulist if len(ulist) > 0 else self.wordlists_path+'/simple-users.txt'
        self.passwords = plist if len(plist) > 0 else self.wordlists_path+'/passwords.txt'
        self.password = "/usr/share/brutex/wordlists/password.lst"
        self.domain = domain if domain != "" else self.domain
        self.cmds=[
            {"name": "nikto", "cmd":'nikto -host '+self.host+' -port '+self.port, "shell": False, "chain": False},
            {"name": "whatweb", "cmd": "whatweb -a 3 "+self.proto_host_port, "shell": False, "chain": False},
            {"name": "nmap-discovery-safe-devfk", "cmd": 'nmap --script "(http* and discovery and safe) or http-devframework or http-default-accounts" -sV -p '+self.port+' '+self.host, "shell": True, "chain": False},
            {"name": "nmap-vuln", "cmd": 'nmap --script "(http* and vuln and not (discovery and safe)) and not dos" -sV -p '+self.port+' '+self.host, "shell": True, "chain": False},
            {"name": "wafw00f", "cmd": 'wafw00f '+self.proto_host_port, "shell": False, "chain": False},
            {"name": "fast_dirsearch", "cmd": "dirsearch -F -r -u " + self.proto_host_port + " -e html,txt," + self.engine, "shell": False,"chain": False},
            {"name": "dirsearch", "cmd": "dirsearch -f -F -r -u "+self.proto_host_port+" -e html,txt,"+self.engine+ "-w /usr/share/wordlists/dirb/common.txt", "shell": False, "chain": False},
            {"name": "slow_dirsearch", "cmd": "dirsearch -f -F -r -u " + self.proto_host_port + " -e " + self.engine+ "-w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt", "shell": False,
             "chain": False},
            {"name": "dirhunt", "cmd": "dirhunt "+self.proto_host_port, "shell": False, "chain": False},
            #{"name": "gobuster", "cmd": "gobuster -k -fw -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -u "+self.proto_host_port+" -x html,txt,"+self.engine, "shell": False, "chain": False},
            #{"name":"dirb","cmd": "dirb -S " + self.proto_host_port + " -X ." + self.engine.replace(",",",."), "shell": False, "chain": False}, #Dirb needs the extension with a point. The flag '-f' in dirsearch makes it behave like dirb (force ext and "/")
            #{"name": "cmssc4n", "cmd": 'cmssc4n -i '+self.victim_file, "shell": False, "chain": False},
            {"name": "cmsmap", "cmd": 'echo "y" | cmsmap -s '+self.proto_host_port, "shell": True, "chain": False},

        ]

        if self.domain and self.ip:
            self.cmds.append({"name": "vhost-brute", "cmd": "vhost-brute.php --domain "+self.domain+" --ip "+self.ip+" --wordlist "+self.wordlists_path+'/subdomains.txt' + (" --ssl" if self.proto == "https" else ""), "shell": False, "chain": False})

        if self.proto == "https":
            self.cmds.append({"name": "sslscan", "cmd": "sslscan "+self.host_port, "shell": False, "chain": False})
            self.cmds.append({"name": "sslyze", "cmd": "sslyze --regular "+self.host_port, "shell": False, "chain": False})

        if self.ebrute or self.protohelp:
            if len(username) > 0:
                cmd = "hydra -l "+username+" -P "+self.passwords+" "+self.host+" "+self.proto+"-get -s "+self.port+"-f -e ns -m /"
            else:
                cmd = "hydra -L "+self.usernames+" -P "+self.passwords+" "+self.host+" "+self.proto+"-get -s "+self.port+" -f -e ns -m /"
            self.cmds.append({"name": "hydra", "cmd": cmd, "shell": False, "chain": False})

        if self.protohelp:
            self.print_help()