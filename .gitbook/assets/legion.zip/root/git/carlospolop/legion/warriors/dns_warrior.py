# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#You can test this module against sizzle.htb (10.10.10.103)

class Dns_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "53"
        Warrior.__init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)
        self.ipv6 = ipv6 if ipv6 != "" else ""
        self.domain = domain if domain != "" else self.domain

        self.ip = self.ip if not self.protohelp else "<IP>"
        self.domain = self.domain if not self.protohelp else "<DOMAIN>"
        self.ipv6 = self.ip if not self.protohelp else "<IPv6>"

        self.cmds = [
            {"name": "dnsrecon_127.0.0.0_24", "cmd": 'dnsrecon -r 127.0.0.0/24 -n ' + self.host, "shell": False, "chain": False},
            {"name": "dnsrecon_127.0.1.0_24", "cmd": 'dnsrecon -r 127.0.1.0/24 -n ' + self.host, "shell": False, "chain": False},

        ]

        if self.domain != "":
            self.cmds.append({"name": "dig_axfr_dom", "cmd": 'dig axfr @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_ANY", "cmd": 'dig axfr @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_A", "cmd": 'dig A @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_AAAA", "cmd": 'dig AAAA @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_TXT", "cmd": 'dig TXT @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_MX", "cmd": 'dig MX @' + self.host + ' ' + self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_NS", "cmd": 'dig NS @' + self.host + ' ' + self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_NS", "cmd": 'dig NS @' + self.host + ' ' + self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dnsrecon_domain", "cmd": 'dnsrecon -d '+ self.domain + ' -a -n '+self.host, "shell": False, "chain": False})
            if self.ebrute or self.protohelp:
                self.wordlist = self.plist if self.plist != "" else self.wordlists_path+'/subdomains.txt'
                self.cmds.append({"name": "dnsrecon_brute", "cmd": 'dnsrecon -D ' + self.wordlist + ' -d ' + self.domain + ' -n ' + self.host, "shell": False, "chain": False})

        if self.ip != "":
            self.cmds.append({"name": "dig_NS", "cmd": 'dig -x ' + self.ip + ' @' + self.host, "shell": False, "chain": False})
            self.cmds.append({"name": "dnsrecon_"+self.ip+"_24", "cmd": 'dnsrecon -r '+self.ip+'/24 -n ' + self.host, "shell": False, "chain": False})

        if self.ipv6 != "":
            self.cmds.append({"name": "dig_NS", "cmd": 'dig -x ' + self.ipv6 + ' @' + self.host, "shell": False, "chain": False})

        if self.protohelp:
            self.print_help()

