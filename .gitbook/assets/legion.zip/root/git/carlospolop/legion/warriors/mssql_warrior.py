# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#You can test this module against querier (10.10.10.125)

class Mssql_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose):
        port = port if port != "0" else "1433"
        Warrior.__init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, protohelp, interactive, verbose)

        self.cmds = [
            {"name": "nmap_mssql", "cmd": 'nmap --script ms-sql-empty-password,ms-sql-info,ms-sql-ntlm-info -sV -p ' + self.port + ' ' + self.host, "shell": False, "chain": False},

        ]

        if self.protohelp:
            self.print_help()
