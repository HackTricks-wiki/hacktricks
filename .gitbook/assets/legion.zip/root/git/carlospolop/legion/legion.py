#!/usr/bin/python3
# -*- coding: utf-8 -*-

import argparse, sys, os

from lib.main import main_run
from lib.interact import LegionPrompt
from os.path import expanduser

# Execute: python3 legion.py <protocol> --host <IP> [--port <PORT>] --workingdir <PATH> [-v] [-b] [-u <username] [-U usernamesList] [-P passwordsList] [--protohelp] [--notuse <Ex: nmap,gobuster,dirsearch>]  


def check_args(args=None):
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('protocol', metavar='proto',
                        help='Protocol to test')
    parser.add_argument('--host', default="",
                        help='Host to test')
    parser.add_argument('--workdir', default="",
                        help='Working directory')
    parser.add_argument('-p', '--port',  type=int, default = 0,
                        help='Port where the protocol is listening (default one will be used if not set). Always default is used by: DNS, RCPinfo')
    parser.add_argument('-b','--brute',  action="store_true",
                        default=False, help='Enable bruteforcing the protocol')
    parser.add_argument('-u','--username', 
                        default="", help='Username to use in bruteforce')
    parser.add_argument('-U','--ulist', default="",
                        help='Usernames to use in bruteforce')
    parser.add_argument('-k', '--password',
                        default="", help='Password to use(smb, community snmp, groupid IKE)')
    parser.add_argument('-P','--plist', default="",
                        help='Passwords to use in bruteforce (pwd brute, dnssubdomain brute, snmp communities brute)')
    parser.add_argument('--protohelp',  action="store_true",
                        default=False, help='Set to get help about the proto')
    parser.add_argument('--notuse', default="",
                        help='Comma separate string of name of tools that you dont want to be used')
    parser.add_argument('--engine', default="",
                        help='USED IN HTTP/s: Set the engine of the web server (php, asp...)')
    parser.add_argument('--ipv6', default="",
                        help='USED IN HTTP/s: Used for reverse dns lookup with ipv6')
    parser.add_argument('--domain', default="",
                        help='When to victim and domain is not the same (maybe DNS) set the domain here and the victimIP in --host')
    parser.add_argument('-i','--interactive', action="store_true", default=False,
                        help='Use interactive mode (Recommended)')

    args = parser.parse_args()
    return (parser, args.protocol.lower(), args.host, args.workdir, str(args.port), args.brute, args.username,
            args.ulist, args.plist, args.protohelp, args.notuse.split(","), args.engine, args.password, args.ipv6,
            args.domain, args.interactive)


def main():
    parser, proto, host, workdir, port, ebrute, username, ulist, plist, protohelp, notuse, engine, password, ipv6, \
        domain, interactive = check_args(sys.argv[1:])
    verbose = False

    if os.getuid() != 0:
        exit("Please, execute this script as root.")

    if workdir == "":
        workdir = expanduser("~")+"/.legion/"
        if not os.path.isdir(workdir):
            os.mkdir(workdir)

    if not interactive:
        main_run(parser, proto, host, workdir, port, ebrute, username, ulist, plist, protohelp, notuse, engine, password, ipv6, \
            domain, interactive, verbose)

    else:
        LegionPrompt(parser, proto, host, workdir, port, ebrute, username, ulist, plist, protohelp, notuse, engine,
                     password, ipv6, domain, verbose).cmdloop()

if __name__ == "__main__":
    main()