# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

class Rdp_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "3389"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)

        self.cmds = [
            {"name": "rdp_nmap", "cmd": 'nmap --script "rdp-enum-encryption or rdp-vuln-ms12-020" -T4 -p '+self.port+' '+ self.host, "shell": True, "chain": False},

        ]

