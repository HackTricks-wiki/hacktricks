# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

# https://github.com/portcullislabs/udp-proto-scanner.git copy the conf file to bin also

#You can test this module against sizzle.htb (10.10.10.103)
#Or against conceal.htb(10.10.10.116)  (hidden snmp detected by udp-proto-scanner)

class Generic_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "1337" #No matter
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)
        self.workdir = self.workdir + "/../"

        if self.ip != "":
            self.cmds = [{"name": "udp-proto-scanner.pl", "cmd": 'udp-proto-scanner.pl ' + self.ip, "shell": False, "chain": False}]

        self.cmds += [
            {"name": "nmap_udp", "cmd": 'nmap -sU -sV -T 4 -oA '+self.workdir+'nmap_udp.xml '+ self.host, "shell": False, "chain": False},
            {"name": "nmap_init", "cmd": 'nmap -sV -sC -O -T 4 -oA '+self.workdir+'nmap_init.xml ' + self.host, "shell": False, "chain": True},
            {"name": "nmap_full_fast", "cmd": 'nmap -sV -sC -T 4 -p - -oA '+self.workdir+'nmap_full_fast.xml ' + self.host, "shell": False, "chain": True},
            {"name": "nmap_full", "cmd": 'nmap -sV -sC -p - -oA '+self.workdir+'nmap_full.xml ' + self.host, "shell": False, "chain": False},
            #{"name": "nmap_udp_full", "cmd": 'nmap -sU -sV -p - ' + self.host, "shell": False, "chain": False}
        ]

