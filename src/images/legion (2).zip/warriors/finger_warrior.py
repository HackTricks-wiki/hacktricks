# -*- coding: utf-8 -*-

from warriors.warrior import Warrior


class Finger_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "79"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)
        self.usernames = ulist if len(ulist) > 0 else self.wordlists_path+'/simple-users.txt'

        self.cmds = [
            {"name": "finger", "cmd": 'finger @' + self.host, "shell": True, "chain": False},
            {"name": "finger_nmap", "cmd": 'nmap -sV --script finger -p ' + self.port + ' ' + self.host, "shell": True, "chain": False},
           #{"name": "msf_finger", "cmd": 'msfconsole -x "use scanner/finger/finger_users"; set RHOSTS '+self.host+'; set RPORT '+self.port+'; run; exit;"', "shell": True, "chain": False}
        ]