# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#Revisado
#apt-get install snmp-mibs-downloader
# in /etc/snmp/snmp.conf comment the line "mibs :"

#You can test this module against condeal.htb (10.10.10.116)

class Snmp_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "161"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)
        self.community = self.password if len(self.password)>0 else "public"
        self.wordlist = self.plist if self.plist != "" else self.wordlists_path+'/snmp_default_pass.txt'

        self.cmds = [
            {"name": "snmpwalkv1", "cmd": 'snmpwalk -v 1 -c ' + self.community + ' ' + self.host, "shell": False, "chain": False},
            {"name": "snmpwalkv2c", "cmd": 'snmpwalk -v 2c -c ' + self.community + ' ' + self.host, "shell": False, "chain": False},
            {"name": "snmp_nmap", "cmd": 'nmap -sV --script "*snmp* and not brute and not dos" -p ' +self.port + " " + self.host, "shell": True, "chain": False},

        ]

        if self.ip != "":
            self.cmds.append({"name": "snmp_check1", "cmd": 'snmp-check -p '+ self.port + ' -c ' + self.community + ' ' + self.ip, "shell": False, "chain": False})
            self.cmds.append({"name": "snmp_check2c", "cmd": 'snmp-check -v 2c -p ' + self.port + ' -c ' + self.community + ' ' + self.ip, "shell": False, "chain": False})

        if self.ebrute:
            self.cmds.append({"name": "hydra_snmp", "cmd": 'hydra -P ' + self.wordlist + ' -f ' + self.host + ' snmp -s '+self.port,
                              "shell": False, "chain": False})

