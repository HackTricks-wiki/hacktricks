# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#apt-get install rpcbind
#You can check this module with irked.htb (10.10.10.117)

class Rpc_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "111"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)

        self.cmds = [
            {"name": "rpcinfo", "cmd": 'rpcinfo ' + self.host, "shell": False, "chain": False},
            {"name": "rpc_nfs_nmap", "cmd": 'nmap -sV --script "nfs-ls or nfs-showmount or nfs-statfs" -p ' + self.port + ' ' + self.host, "shell": True, "chain": False},
            {"name": "showmount", "cmd": 'showmount -e ' + self.host, "shell": True, "chain": False},
            # {"name": "msf_rpc_nfs", "cmd": 'msfconsole -x "scanner/nfs/nfsmount"; set RHOSTS '+self.host+'; set RPORT '+self.port+'; run; exit;"', "shell": True, "chain": False}
        ]

