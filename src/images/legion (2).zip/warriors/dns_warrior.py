# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#You can test this module against sizzle.htb (10.10.10.103)

class Dns_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "53"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)

        self.cmds = [
            {"name": "dnsrecon_127.0.0.0_24", "cmd": 'dnsrecon -r 127.0.0.0/24 -n ' + self.host, "shell": False, "chain": False},
            {"name": "dnsrecon_127.0.1.0_24", "cmd": 'dnsrecon -r 127.0.1.0/24 -n ' + self.host, "shell": False, "chain": False},
            {"name": "dns_nmap", "cmd": 'nmap -n --script "(default and *dns*) or fcrdns or dns-srv-enum or dns-random-txid or dns-random-srcport" ' + self.host, "shell": True, "chain": False} ,

        ]

        if self.domain != "":
            self.cmds.append({"name": "dig_axfr_dom", "cmd": 'dig axfr @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_ANY", "cmd": 'dig axfr @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_A", "cmd": 'dig A @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_AAAA", "cmd": 'dig AAAA @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_TXT", "cmd": 'dig TXT @' + self.host + ' '+ self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_MX", "cmd": 'dig MX @' + self.host + ' ' + self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dig_NS", "cmd": 'dig NS @' + self.host + ' ' + self.domain, "shell": False, "chain": False})
            self.cmds.append({"name": "dnsrecon_domain", "cmd": 'dnsrecon -d '+ self.domain + ' -a -n '+self.host, "shell": False, "chain": False})
            if self.ebrute:
                self.wordlist = self.plist if self.plist != "" else self.wordlists_path+'/subdomains.txt'
                self.cmds.append({"name": "dnsrecon_brute", "cmd": 'dnsrecon -D ' + self.wordlist + ' -d ' + self.domain + ' -n ' + self.host, "shell": False, "chain": False})

        if self.ip != "":
            self.cmds.append({"name": "dig_NS", "cmd": 'dig -x ' + self.ip + ' @' + self.host, "shell": False, "chain": False})
            self.cmds.append({"name": "dnsrecon_"+self.ip+"_24", "cmd": 'dnsrecon -r '+self.ip+'/24 -n ' + self.host, "shell": False, "chain": False})

        if self.ipv6 != "":
            self.cmds.append({"name": "dig_NS", "cmd": 'dig -x ' + self.ipv6 + ' @' + self.host, "shell": False, "chain": False})

