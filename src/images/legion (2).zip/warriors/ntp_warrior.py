# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#apt-get install rpcbind
#You can check this module with irked.htb (10.10.10.117)

class Ntp_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "123"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)

        self.cmds = [
            {"name": "ntpq_readvar", "cmd": 'ntpq -c readvar ' + self.host, "shell": False, "chain": False},
            {"name": "ntpq_monlist", "cmd": 'ntpq -c monlist ' + self.host, "shell": False, "chain": False},
            {"name": "ntpq_peers", "cmd": 'ntpq -c peers ' + self.host, "shell": False, "chain": False},
            {"name": "ntpq_listpeers", "cmd": 'ntpq -c listpeers ' + self.host, "shell": False, "chain": False},
            {"name": "ntpq_ntpversion", "cmd": 'ntpq -c ntpversion ' + self.host, "shell": False, "chain": False},
            {"name": "ntpq_sysinfo", "cmd": 'ntpq -c sysinfo ' + self.host, "shell": False, "chain": False},
        ]
