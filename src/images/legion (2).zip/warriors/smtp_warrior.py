# -*- coding: utf-8 -*-

from warriors.warrior import Warrior


class Smtp_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "25"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)

        self.cmds = [
            {"name": "smtp_nmap", "cmd": 'nmap --script "smtp-open-relay or (default and *smtp*)" -p ' + self.port + ' ' + self.host, "shell": True, "chain": False},
            #{"name": "msf_smtp_version", "cmd": 'msfconsole - x "use scanner/smtp/smtp_version; set rhosts '+self.host+'; set RPORT '+self.port+' run; exit;"', "shell": True, "chain": False},
        ]
