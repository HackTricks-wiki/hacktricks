# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

#You can test this module against sizzle.htb (10.10.10.103)

class Smb_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "445"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)

        self.cmds = [
            {"name": "enum4linux", "cmd": 'enum4linux -a -u "'+self.username+'" -p "'+self.password+'" '+self.host, "shell": True, "chain": False},
            {"name": "smb_nmap", "cmd": 'nmap -sV --script "(safe and smb*) or smb-enum-*" -p '+self.port+',135,139 ' + self.host, "shell": True, "chain": False},
            {"name": "smbmap", "cmd": 'smbmap -u "'+self.username+'" -p "'+self.password+'" -H '+self.host+" -P "+self.port, "shell": True, "chain": False},
            {"name": "smbclient", "cmd": "smbclient -U '"+self.username+"%"+self.password+"' -L //" + self.host, "shell": False, "chain": False},
            {"name": "nbtscan", "cmd": 'nbtscan ' + self.host, "shell": False, "chain": False},
            #{"name": "msf_smb_version", "cmd": 'msfconsole - x "use scanner/smb/smb_version; set rhosts '+self.host+'; run; exit;"', "shell": True, "chain": False},
        ]

        if self.username == "" or ("<" == username[0] and ">" == username[-1]):
            self.cmds.append({"name": "smbmap_guest", "cmd": 'smbmap -u "guest" -p "" -H '+self.host+" -P "+self.port, "shell": True, "chain": False})
            self.cmds.append({"name": "smbclient_guest", "cmd": "smbclient -U 'guest%' -L //" + self.host, "shell": True, "chain": False})
            self.cmds.append({"name": "enum4linux_guest", "cmd": 'enum4linux -a -u "guest" -p "" '+self.host, "shell": True, "chain": False})
