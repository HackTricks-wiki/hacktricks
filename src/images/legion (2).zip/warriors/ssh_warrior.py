# -*- coding: utf-8 -*-

from warriors.warrior import Warrior

class Ssh_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "22"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)
        self.usernames = ulist if len(ulist) > 0 else self.wordlists_path+'/simple-users.txt'

        self.cmds = [
            {"name": "ssh_nmap", "cmd": 'nmap -sV --script "ssh-auth-methods or ssh-auth-methods or ssh2-enum-algos or sshv1" -p ' + self.port + ' ' + self.host, "shell": True, "chain": False},
            {"name": "ssh_sslscan", "cmd": "sslscan "+self.host_port, "shell": False, "chain": False},
            {"name": "ssh_sslyze", "cmd": "sslyze --regular "+self.host_port, "shell": False, "chain": False},
            {"name": "ssh_version", "cmd": 'timeout 10 nc -vn ' + self.host + ' ' + self.port, "shell": True, "chain": False},
        ]

        msfmodules = [{"path": "scanner/ssh/ssh_enumusers", "toset": {"RHOSTS": self.host, "RPORT": self.host, "USER_FILE": self.usernames}},
                      {"path": "auxiliary/scanner/ssh/ssh_version", "toset": {"RHOSTS": self.host, "RPORT": self.host}}, ]

        self.cmds.append({"name": "ftp_msf", "cmd": self.create_msf_cmd(msfmodules), "shell": True, "chain": False})
