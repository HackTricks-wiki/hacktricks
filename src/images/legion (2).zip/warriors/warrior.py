# -*- coding: utf-8 -*-

import sys, os, socket, re

from termcolor import colored
from subprocess import Popen
from multiprocessing import Process, Queue
from time import sleep


def print_error(msg):
    print(colored("[-] Error: "+msg, 'red'))

class Warrior:
    def __init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain):
        self.host = host
        self.port = port
        self.proto = proto
        self.workdir = workdir + "/" + self.host + "/" + self.proto + "/" +self.port
        self.ebrute = ebrute
        self.username = username
        self.ulist = ulist
        self.password = password
        self.plist = plist
        self.notuse = notuse if type(notuse) is list else notuse.split(",")
        self.interactive = interactive
        self.verbose = verbose
        self.engine = engine
        self.ipv6 = ipv6
        self.domain = domain

        self.q = Queue()
        self.cmds = []
        self.processes = []
        self.proto_host = self.proto+"://"+self.host
        self.host_port = self.host+":"+self.port
        self.proto_host_port = self.proto_host+":"+self.port
        self.victim_file = self.workdir+"/"+"victim"
        self.isChained = False
        self.ip = self.host if re.match("^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$", self.host) else ""
        self.wordlists_path = os.path.dirname(os.path.realpath(__file__)) + '/../wordlists/'

        #If host is a domain
        if re.match("^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$", self.host):
            self.ip = socket.gethostbyname(self.host)
            self.domain = self.host if self.domain == "" else self.domain

        self.write_host()

    def execute(self, q, cmd, name, shell=False):
        cmdl = cmd
        if not shell:
            cmd = cmd.split(" ")
        with open(self.workdir+"/"+name+".out", "wb") as out, open(self.workdir+"/"+name+".err", "wb") as err:
            try:
                pw = Popen(cmd, stdout=out, stderr=err, shell=shell)
                print(colored("Executing " + name + " with PID:" + str(pw.pid) + " the command: " + cmdl, 'yellow'))
                q.put(name+","+str(pw.pid))
                pw.communicate()
            except Exception as e:
                print_error("Something has happened with "+name+" (Exception: "+str(e)+")")
        if self.interactive:
            print(colored(name, 'green'))
            if self.verbose:
                self.getout(name)

    def get_all_queue(self):
        '''Obtiene la relacion  "nombre",pid  de los mensajes de la cola'''
        msgs = []
        fm = {}
        while not self.q.empty():
            msgs.append(self.q.get())

        for msg in msgs:
            msgsplit = msg.split(",")
            if len(msgsplit) > 1:
                fm[msgsplit[0]] = msgsplit[1]
        return fm

    def exec_proc(self, cmd):
        CY = '\033[33m'
        NC = '\033[0m'
        p = { "name": cmd["name"], "cmd": cmd["cmd"] }
        p["proc"] = Process(target=self.execute, args=(self.q, cmd["cmd"], cmd["name"], cmd["shell"]))
        self.processes.append(p)
        self.processes[-1]["proc"].start()
        if cmd["chain"]:  # If chain, wait it to finish
            self.isChained = True
            if not self.interactive:
                sys.stdout.write('\r'+CY+"[I] Waiting..."+NC)
            self.processes[-1]["proc"].join()
            if not self.interactive:
                sys.stdout.flush()
            self.isChained = False

    def get_procs_info(self):
        return (self.processes, self.isChained)

    def get_proto(self):
        return self.proto

    def print_help(self):
        print("For "+colored(self.proto.upper(), 'cyan')+" will be executed:")
        for cmd in self.cmds:
            print(colored(cmd["name"]+":", 'blue'), colored(cmd["cmd"], 'yellow'))

    def write_host(self):
        if not os.path.exists(self.workdir):
            os.makedirs(self.workdir)
        with open(self.victim_file,'w') as f:
            f.write(self.host)

    def run(self):
        CG = '\033[92m'
        NC = '\033[0m'
        for cmd in self.cmds:
            if all([(tool not in cmd["cmd"]) if len(tool)>1 else True for tool in self.notuse ]):
                self.exec_proc(cmd)
                sleep(0.5)
        if not self.interactive:
            while any(p["proc"].is_alive() for p in self.processes):
                sleep(1)
                sys.stdout.flush()
                to_write = "\rProcessing "+", ".join([p["name"] if p["proc"].is_alive() else CG+p["name"]+NC for p in self.processes])+"\t\t\tCompleted: {0:03}%".format(int(len([p for p in self.processes if not p["proc"].is_alive()])*100/len(self.processes)))
                sys.stdout.write(to_write)
            sys.stdout.flush()

    def getout(self, filename):
        '''Get the output of a executed tool: getout smbclient'''
        name = filename + ".out"
        for root, dirs, files in os.walk(self.workdir):
            if name in files:
                with open(os.path.join(root, name), 'r') as f:
                    print(f.read())
                    break

    def create_msf_cmd(self, params):
        cmd = "msfconsole -x '"
        for param in params:
                cmd += "use " + param["path"] + ";"
                for key in param["toset"]:
                    cmd += "set "+key+" "+param["toset"][key]+";"
        cmd += "run;'"
        return cmd
