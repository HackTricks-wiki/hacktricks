# -*- coding: utf-8 -*-

from warriors.warrior import Warrior


class Telnet_warrior (Warrior):
    def __init__(self, host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine, ipv6, domain, interactive, verbose):
        port = port if port != "0" else "23"
        Warrior.__init__(self, host, port, proto, workdir, ebrute, username, ulist, password, plist, notuse, interactive, verbose, engine, ipv6, domain)

        self.cmds = [
            {"name": "telnet_nmap", "cmd": 'nmap --script "*telnet* and safe" -p ' + self.port + ' ' + self.host, "shell": True, "chain": False},
            {"name": "telnet_version", "cmd": 'timeout 10 nc -vn ' + self.host + ' ' + self.port, "shell": True, "chain": False},
        ]

        msfmodules = [{"path": "auxiliary/scanner/telnet/telnet_version", "toset": {"RHOSTS": self.host, "RPORT": self.host}}, ]

        self.cmds.append({"name": "ftp_msf", "cmd": self.create_msf_cmd(msfmodules), "shell": True, "chain": False})