#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys, os, re

from termcolor import colored

from warriors.dns_warrior import Dns_warrior
from warriors.finger_warrior import Finger_warrior
from warriors.generic_warrior import Generic_warrior
from warriors.http_warrior import Http_warrior
from warriors.ike_warrior import Ike_warrior
from warriors.ldap_warrior import Ldap_warrior
from warriors.mssql_warrior import Mssql_warrior
from warriors.mysql_warrior import Mysql_warrior
from warriors.ntp_warrior import Ntp_warrior
from warriors.oracle_warrior import Oracle_warrior
from warriors.rdp_warrior import Rdp_warrior
from warriors.rpc_warrior import Rpc_warrior
from warriors.smb_warrior import Smb_warrior
from warriors.snmp_warrior import Snmp_warrior
from warriors.smtp_warrior import Smtp_warrior
from warriors.ssh_warrior import Ssh_warrior
from warriors.telnet_warrior import Telnet_warrior


valid_protos = ["dns", "finger", "generic", "http", "https", "ike", "ldap", "mssql", "mysql", "ntp", "oracle", 
                "rdp", "rpc", "smb", "smtp", "snmp", "ssh", "telnet", "/"]

def print_error(msg):
    print(colored("[-] Error: "+msg, 'red'))

def main_run(parser, proto, host, workdir, port, ebrute, username, ulist, plist, protohelp, notuse, engine, password,
             ipv6, domain, interactive, verbose):

    if not proto in valid_protos:
        if not interactive:
            parser.print_help(sys.stderr)
            sys.exit(1)
        else:
            print_error("Protocol "+proto+" is not valid")
            return -1

    if not os.path.isdir(workdir) or not os.access(workdir, os.W_OK):
        if not interactive:
            parser.print_help(sys.stderr)
            print_error("Not valid directory or not writable: " + workdir)
            sys.exit(2)
        else:
            print_error("Not valid directory or not writable: " + workdir)
            return -1

    if not protohelp and not host:
        if not interactive:
            parser.print_help(sys.stderr)
            print_error("A host is needed")
            sys.exit(3)
        else:
            print_error("Please, set a host")
            return -1

    if not re.match("^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$", host) and not re.match(
            "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$",
            host):
        if not interactive:
            parser.print_help(sys.stderr)
            print_error("The provided host is not an IP nor a valid Domain")
            sys.exit(4)
        else:
            print_error("The provided host is not an IP nor a valid Domain")
            return -1
        
    if protohelp:
        host = "<HOST>" if not host else host
        port = "<PORT>" if not port else port
        username = "<USERNAME>" if not username else username
        ulist = "<USERsLIST>" if not ulist else ulist
        password = "<PASSWORD>" if not password else password
        plist = "<PASSWORDsLIST>" if not plist else plist
        engine = "<ENGINE>" if not engine else engine
        ipv6 = "<IPv6>" if not ipv6 else ipv6
        domain = "<DOMAIN>" if not domain else domain

    if proto == "dns":
        warrior = Dns_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                              ipv6, domain, interactive, verbose)

    elif proto == "finger":
        warrior = Finger_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                                 ipv6, domain, interactive, verbose)
    
    elif proto == "generic":
        warrior = Generic_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                                  ipv6, domain, interactive, verbose)

    elif proto == "http":
        warrior = Http_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                               ipv6, domain, interactive, verbose)

    elif proto == "https":
        warrior = Http_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                               ipv6, domain, interactive, verbose)

    elif proto == "ike":
        warrior = Ike_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                              ipv6, domain, interactive, verbose)

    elif proto == "ldap":
        warrior = Ldap_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                               ipv6, domain, interactive, verbose)

    elif proto == "mssql":
        warrior = Mssql_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                                ipv6, domain, interactive, verbose)

    elif proto == "mysql":
        warrior = Mysql_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                                ipv6, domain, interactive, verbose)

    elif proto == "ntp":
        warrior = Ntp_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                              ipv6, domain, interactive, verbose)

    elif proto == "oracle":
        warrior = Oracle_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                                 ipv6, domain, interactive, verbose)

    elif proto == "rdp":
        warrior = Rdp_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                              ipv6, domain, interactive, verbose)

    elif proto == "rpc":
        warrior = Rpc_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                              ipv6, domain, interactive, verbose)

    elif proto == "smb":
        warrior = Smb_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                              ipv6, domain, interactive, verbose)

    elif proto == "smtp":
        warrior = Smtp_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                               ipv6, domain, interactive, verbose)

    elif proto == "snmp":
        warrior = Snmp_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                               ipv6, domain, interactive, verbose)

    elif proto == "ssh":
        warrior = Ssh_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                              ipv6, domain, interactive, verbose)

    elif proto == "telnet":
        warrior = Telnet_warrior(host, port, workdir, proto, ebrute, username, ulist, password, plist, notuse, engine,
                                 ipv6, domain, interactive, verbose)

    if protohelp:
        warrior.print_help()
    else:
        if not interactive:
            warrior.run()
        else:
            return warrior
